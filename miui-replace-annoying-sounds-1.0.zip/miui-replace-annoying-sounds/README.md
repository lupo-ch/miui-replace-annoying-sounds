#Replace the annoying MIUI sounds: charging.ogg, disconnect.ogg with silence.ogg

TLDR; This module replace the annoying MIUI sounds: charging.ogg disconnect.ogg

## Installation

zip the contents of this repo and install it in your rooted phone with magisk-Manager.

## Details

The annoying MIUI sounds: charging.ogg and disconnect.ogg are placed in

/system/media/audio/ui/

This module replaces this files in /system/media/audio/ui/ with the silence file: silence.ogg

